<?php
/*
 * */

define('SYSTEM_ROOT_E', dirname(__FILE__).'/');
include '../ayangw/common.php';
require_once(SYSTEM_ROOT_E."epay/epay.config.php");
require_once(SYSTEM_ROOT_E."epay/epay_notify.class.php");

//计算得出通知验证结果
$alipayNotify = new AlipayNotify($alipay_config);
empty($_COOKIE['auth'])?exit():null;
$verify_result = $alipayNotify->verifyNotify();

if($verify_result) {
    $trade_status = $_GET['trade_status'];
    if($_GET['trade_status'] == 'TRADE_FINISHED') {
		//退款日期超过可退款期限后（如三个月可退款），支付宝系统发送该交易状态通知
    }else if ($_GET['trade_status'] == 'TRADE_SUCCESS') {
          if(callbackprocess()){
              echo "success";
          }else{
              echo "fail";
          }
          exit();
    }
    echo "success";
} 
else {
    //验证失败
    echo "fail";
}
?>