﻿<?php

define('SYSTEM_ROOT_E', dirname(__FILE__) . '/');
include '../ayangw/common.php';
function showalert($msg,$status,$orderid=null){
    global $ereturn;
    echo '<meta charset="utf-8"/><script>window.location.href="'.$ereturn.$orderid.'";</script>';
}

$_POST = $_GET;
ksort($_POST); //排序post参数
reset($_POST); //内部指针指向数组中的第一个元素
$sign = '';
foreach ($_POST AS $key => $val) {
    if ($val == '') continue;
    if ($key != 'sign') {
        if ($sign != '') {
            $sign .= "&";
            $urls .= "&";
        }
        $sign .= "$key=$val"; //拼接为url参数形式
        $urls .= "$key=" . urlencode($val); //拼接为url参数形式
    }
}

if (!$_POST['pay_no'] || md5($sign . $conf['epay_key']) != $_POST['sign']) { //不合法的数据 KEY密钥为你的密钥
    showalert('验证失败！', 4, '订单回调验证失败！');
} else { //合法的数据
    $trade_no = $_POST['pay_no'];
    $out_trade_no = $_POST['param'];
    $post = "";
    foreach ($_POST as $key => $value) {
        if($post!="") $post.="&";
        $post = $post .$key."=".$value;
    }   
    $url = $siteurl."other/codepay_notify.php";
    $returnmsg = get_curl($url, $post);
    wsyslog("订单回调！","订单编号：".$out_trade_no."、异步返回：".$returnmsg);
    showalert('您所购买的商品已付款成功，感谢购买！',1,$trade_no);

   
}
?>