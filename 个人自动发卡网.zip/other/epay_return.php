﻿<?php
/*
 * 源码来源：龙少网络
 * */

define('SYSTEM_ROOT_E', dirname(__FILE__).'/');
include '../ayangw/common.php';
require_once(SYSTEM_ROOT_E."epay/epay.config.php");
require_once(SYSTEM_ROOT_E."epay/epay_notify.class.php");

//计算得出通知验证结果
$alipayNotify = new AlipayNotify($alipay_config);
empty($_COOKIE['auth'])?exit():null;
$verify_result = $alipayNotify->verifyReturn();
if($verify_result) {
	//商户订单号	
	$out_trade_no = $_GET['out_trade_no'];

	//支付宝交易号	
	$trade_no = $_GET['trade_no'];

	//交易状态
	$trade_status = $_GET['trade_status'];

	/*$sql = "SELECT * FROM ayangw_order WHERE out_trade_no='{$out_trade_no}' limit 1";
        $srow = $DB->get_row($sql);*/
       
    if($_GET['trade_status'] == 'TRADE_FINISHED' || $_GET['trade_status'] == 'TRADE_SUCCESS') {
                    $post = "";
                    foreach ($_GET as $key => $value) {
                        if($post!="") $post.="&";
                        $post = $post .$key."=".$value;
                    }   
                    $returnmsg = get_curl($siteurl."other/epay_notify.php?".$post);
                    file_put_contents("1.txt",$out_trade_no."----".$returnmsg);
                    wsyslog("订单回调！","订单编号：".$out_trade_no."、异步返回：".$returnmsg);
		    showalert('您所购买的商品已付款成功，感谢购买！',1,$out_trade_no);
		
    }
    else {
        
      echo "trade_status=".$_GET['trade_status'];
    }
}
else {
    //验证失败
	showalert('验证失败！',4,'订单回调验证失败！');
}
function showalert($msg,$status,$orderid=null){
    global $ereturn;
    echo '<meta charset="utf-8"/><script>window.location.href="'.$ereturn.$orderid.'";</script>';
}
?>