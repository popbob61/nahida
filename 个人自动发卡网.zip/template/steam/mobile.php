<html>
<head><meta charset="utf-8">
   <meta content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no"  name="viewport" />
  <title><?=$conf['title']?> - <?php echo  $conf['ftitle'];  ?></title>
	<link rel="stylesheet" href="http://at.alicdn.com/t/font_687918_ikr0g02dgdp.css" type="text/css" media="all">
	<link rel="stylesheet" type="text/css" href="<?=$siteurl?>/template/steam/static/css/style.css">
	<link rel="stylesheet" type="text/css"  href="<?=$siteurl?>/template/steam/static/css/index.css">
        
                  <script src="<?=$siteurl?>assets/layer/mobile/layer.js"></script>
                  <style>
                      .bor{
                          border:1px solid orange;
                      }
                  </style>
</head>
<body>
	<div>
		<div id="id1057"class="id1057">
			<div class='a1'><?=$conf['title']?></div>
			<div class='a2'>
				<div class='b1'>
					   <a href="http://wpa.qq.com/msgrd?v=1&uin=<?php echo $conf['zzqq']; ?>&site=<?= $siteurl ?>&menu=yes'" target="_blank">
                                               <div class='c1'>
						<div class='d1'>
							<i class='e1'></i>
							<div class='e2'>联系客服</div>
						</div>
					</div>
                                           </a>
                                     <a href="<?= $siteurl ?>query.php" >
                                              
					<div class='c2'>
						<div class='d1'>
							<i class='e1'></i>
							<div class='e2'>查询订单</div>
						</div>
					</div>
                                      </a>
				</div>
			</div>
			<div class='a3'>
				<div class='b1'>
					<div class='c1'>商家公告</div>
					<div class='c2'>  <?php echo $conf['notice1'];?></div>
				</div>
			</div>
			<div class='a4'>
				<div class='b1'>
					<div class='c1'>商品分类</div>
					<div class='c2'>
						<select class='d1'  id="goodstype" onchange="getgoodslist(this.value)">
                    <?php
                    $sql = "select * from ayangw_type where state = 1 order by sort desc";
                    $rs = $DB->query($sql);
                    $i = 0;
                    while ($row = $DB->fetch($rs)){

                           ?>
                        <option value="<?=$row['id']?>" <?=$i==0?"selected":""?>><?=$row['tName']?></option>

                     <?php
                     $i++;
                     }
                    ?>
						</select>
					</div>
				</div>
			</div>
			<div class='a5'>
				<div class='b1'>
					<div class='c1'>商品名称</div>
					<div class='c2'>
						<select class='d1' id="goodsshow" onchange="getgoodsmsg()">

						</select>
					</div>
				</div>
			</div>
			<div class='a6'>
				<div class='b1'>
					<div class='c1'>商品详情</div>
					<div class='c2'>
						<div class='d1'>
							<img id="goodsimg"  src="http://pic25.photophoto.cn/20121216/0010023949794270_b.jpg"class='e1'></img>
							<div class='e2' id="goodsinfo" style="word-break:break-all;width: 70%"></div>
						</div>
					</div>
				</div>
			</div>
			<div class='a7'>
				<div class='b1'>
					<div class='c1'>
						<div class='d1'>商品单价</div>
						<div class='d2'>
							<div class='e1' id="goodsprice">0.00</div>
							<div class='e2'>元</div>
						</div>
					</div>
					<div class='c2'>
						<div class='d1'>购买数量</div>
						<div class='d2'>
                                                    <input  type="number"class='e1' id="number" value="1" min="1" onblur="checknumber()"></input>
						</div>
					</div>
					<div class='c3'  style="<?=$conf['showKc']==2?"display:none;":""?>">
						<div class='d1'>商品库存</div>
						<div class='d2'>
							<div class='e1' id="goodskc">0</div>
						</div>
					</div>
				</div>
			</div>
			<div class='a8'>
				<div class='b1'>
					<div class='c1'>联系QQ</div>
					<div class='c2'>
                                            <input  type="text"placeholder="输入您的QQ号码"class='d1' id="qq"></input>
					</div>
				</div>
			</div>
                        <div class='a8' style="<?=$conf['paypasstype']==2?"display:none":""?>">
				<div class='b1'>
					<div class='c1'>提取密码</div>
					<div class='c2'>
                                            <input id="paypass"  type="text"placeholder="输入您的提取密码，QQ或电话"class='d1'></input>
					</div>
				</div>
			</div>
			<div class='a9'>请选择支付方式</div>
			<div class='a10'>
                            <input id="type" type="hidden">
                            <input id="typefs" type="hidden">
				<div class='b1'>
                                       <?php if($conf['switch_alipay']==1){ ?>
                                    <div class='c1' style="cursor: pointer" onclick="paytype(this,'alipay','支付宝')">
						<div class='d1'>
							<i class='e1'></i>
							<div class='e2'>支付宝</div>
						</div>
					</div>
                                     <?php } ?>
                        <?php if($conf['switch_wxpay']==1){ ?>
					<div class='c2' style="cursor: pointer" onclick="paytype(this,'wxpay','微信')">
						<div class='d1'>
							<i class='e1'></i>
							<div class='e2'>微信</div>
						</div>
					</div>
                                       <?php } ?>
   <?php if($conf['switch_qqpay']==1){ ?>
					<div class='c3' style="cursor: pointer" onclick="paytype(this,'qqpay','QQ钱包')">
						<div class='d1'>
							<i class='e1'></i>
							<div class='e2'>QQ钱包</div>
						</div>
					</div>
                                      <?php } ?>
				</div>
			</div>
			<div class='a11'>
				<div class='b1'>
					<div class='c1'>
						<div class='d1'>
							<div class='e1'>应付总额：</div>
							<div class='e2' id="allmoney">0.00</div>
							<div class='e3'>元</div>
						</div>
					</div>
                                    <div class='c2' style=";cursor: pointer;" onclick="submit_pay()">
						<div class='d1'>确认支付</div>
					</div>
				</div>
			</div>
			<div class='a12'>
			</div>
		</div>
	</div>
     <?php
    if($conf['payapi'] == 5){
        echo '<div style="display: none"><img src="/codepay/codepay_cron.php" width="1" height="1"></div>';
    }
    ?>
</body>
</html>
   <script src="<?=$siteurl?>assets/jquery/jquery.cookie.js"></script>
  <script src="<?=$siteurl?>assets/jquery/jquery.min.js"></script>
    <script>
         var list = null;
         var kcnumber = 0;
         var tid = $("#goodstype option:selected").val();
   getgoodslist(tid);
function jisuanprice(){
       var number = parseInt($("#number").val());
       var price = $("#goodsprice").text();
       var allprice = (price*number).toFixed(2);
       $("#allmoney").text(allprice);
}
function paytype(e,type,typefs){
    $(".c1").removeClass("bor");
    $(".c2").removeClass("bor");
    $(".c3").removeClass("bor");
    $(e ).addClass("bor");
    $("#type").val(type);
    $("#typefs").val(typefs);
    jisuanprice();
}
function checknumber(){
    var num = $("#number").val();
    if(parseInt(num) > kcnumber){
        $("#number").val(kcnumber);
    }
    if(parseInt(num) <1){
         $("#number").val(1);
    }
     jisuanprice();
}
///获取商品
function getgoodslist(tid){
    
  var ii =  layer.open({type: 2,content: '加载中' });
  $.ajax({
            type : "POST",
            url : "ajax.php?act=getgoods&r="+Date.parse(new Date()),
            data : {"tid":tid},
            dataType : 'json',
            async:false,
            success : function(data) {
                    layer.close(ii);
                    if(data.code == 1){
                        if(data.number > 0){
                             list = data.goodslist;
                             var option = "";
                             for(var i=0;i<list.length;i++){
                                 var goods = list[i];
                                 option = option + "<option value='"+goods.id+"' "+(option==""?"selected":"")+">"+goods.name+"</option>";
                             }
                             $("#goodsshow").html(option);
                             getgoodsmsg();
                        }else{
                              $("#goodsshow").html("<option value='-1'>无商品</option>");
                           $("#goodsinfo ").html("");
                            $("#goodsprice").text("0");
                            $("#goodskc").text(0);
                            kcnumber=0;
                           
                     layer.open({
                        content: '当前分类下面暂时没有商品'
                        ,skin: 'msg'
                        ,time: 2 
                      });
                        }
                    }else{
                        list = null;
                            layer.msg(data.msg);
                            return false;
                    }
            },
            error:function(data){
                     layer.close(ii);
                      list = null;
                       layer.open({
                        content: '系统错误'
                        ,skin: 'msg'
                        ,time: 2 
                      });
                    return false;
                    }
    })
}
//获取商品详细参数
function getgoodsmsg(){
    kcnumber=0;
    var gid = $("#goodsshow option:selected").val();
     for(var i=0;i<list.length;i++){
        var goods = list[i];
        if(goods.id != gid)    continue;
        if(goods.id == gid){
            $("#goodsimg").attr("src",goods.imgs);
            $("#goodsinfo ").html(goods.info);
            $("#goodsprice").text(goods.price);
            $("#goodskc").text(goods.kccount);
            kcnumber = goods.kccount;
            $("#number").val(1);
             jisuanprice();
        }
     }
}
function submit_pay(){
             var timestamp =Date.parse(new Date());
            var rand = Math.floor(Math.random()*(99999-99+1)+99);
            var tradeno =  timestamp+""+rand;
            var gid = $("#goodsshow option:selected").val();
            var gname = $("#goodsshow option:selected").text();
            var price = $("#goodsprice").text();
            var goodskc = parseInt($("#goodskc").text());
            var number = parseInt($("#number").val());
            var qq = $("#qq").val();
            var type = $("#type").val();//付款方式 
            var typefs = $("#typefs").val();//付款方式2
            var paypass = $("#paypass").val();
            var allprice = (price*number).toFixed(2);
           if(qq=="" || isNaN(qq) || qq.length <5){
                 layer.open({
                    content: '联系QQ不能为空'
                    ,btn: '我知道了'
                  });
                  return;
            }
            if(gid <= 0){
                 layer.open({
                    content: '该商品无法下单'
                    ,btn: '我知道了'
                  }); return;
            }
            if(goodskc < 1 || number > goodskc || kcnumber!=goodskc){
                 layer.open({
                    content: '商品库存不足,无法购买'
                    ,btn: '我知道了'
                  }); return;
            }
             if(typefs==""||type==""||typefs == undefined || type == undefined || typefs=="undefined" || type == "undefined"){
                    layer.open({
                    content: '请选择您的支付方式'
                    ,btn: '我知道了'
                  }); return;
    }
             var ii =  layer.open({type: 2,content: '加载中' });
           $.ajax({
                    type : "POST",
                    url : "ajax.php?act=createorder&r="+Date.parse(new Date()),
                    data : {"tradeno":tradeno,"gid":gid,"allprice":allprice,"price":price,"qq":qq,"type":type,"number":number,"paypass":paypass},
                    dataType : 'json',
                    success : function(data) {
                             layer.close(ii);
                            if(data.code == 1){
                               
                                 var html = "<span style='color:#000;display: inline-block;text-align: left'>"
                                            +"订单编号："+data.tradeno
                                            +"<br>商品名称："+gname
                                            +"<br>商品单价："+price+"￥"
                                            +"<br>购买数量："+number
                                            +"<br>联系QQ："+qq
                                            +"<br>支付方式："+typefs
                                            +"<br>应付款：<font style='font-size:18px' color=red>"+allprice+"</font>￥"
                                            +"</span>";    
                            
                                document.cookie="tradeno="+data.tradeno;
                                 document.cookie="paypass="+paypass;
                                 layer.open({
                                        title:"请核对订单信息",
                                       content: html
                                       ,btn: ['立即付款', '暂不付款']
                                       ,yes: function(index){
                                          window.location.href='./other/submit.php?paynumber='+data.md5_tradeno;
                                      }
                                    });
                          
                            }else{
              
                                      layer.open({
                                        content: data.msg
                                        ,skin: 'msg'
                                        ,time: 2 
                                      });
                                    return false;
                            }
                    },
                    error:function(data){
                             layer.close(ii);
                             layer.open({
                        content: '系统错误'
                        ,skin: 'msg'
                        ,time: 2 
                      });
                            return false;
                            }
            })
}
    </script>