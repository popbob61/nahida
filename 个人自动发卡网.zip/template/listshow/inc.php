<?php return array('links'=>' <div class="am-u-sm-6 am-u-md-4 am-u-lg-2 am-u-end" style="padding:2px">
                        <a type="button" class="am-btn am-btn-success am-btn-hollow am-square" 
style="width:100%;color:#000" href="http://www.zv0.cn/" target="_blank">最新资料通知中心</a>
                    </div>

                    <div class="am-u-sm-6 am-u-md-4 am-u-lg-2 am-u-end" style="padding:2px">
                        <a type="button" class="am-btn am-btn-success am-btn-hollow am-square" 
style="width:100%;color:#000" href="https://codepay.fateqq.com/i/28807" target="_blank">码支付</a>
                    </div>

