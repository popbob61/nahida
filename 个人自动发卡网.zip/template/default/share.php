<?php
@header('Content-Type: text/html; charset=UTF-8');

$gid = intval($_GET['gid'])-1000;
$goods = getgoods($gid);
if(!$goods){
    exit('<script>window.location.href="'.$siteurl.'index.php";</script>');
}
$type = getgoodstype($goods['tpId']);
$kccount = $DB->count("select count(id) from ayangw_km where stat = 0 and gid = ".$gid)
?>

<!DOCTYPE html>
<html lang="zh-cn">
<head>
  <meta charset="utf-8"/>
 <meta content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no"  name="viewport" />
  <title><?=$conf['title']?> - <?php echo  $conf['ftitle'];  ?></title>
  <meta name="keywords" content="<?php echo $conf['keywords']; ?>">
  <meta name="description" content="<?php echo $conf['description'];  ?>">
   <link rel="shortcut icon" type="image/x-icon" href="<?=$siteurl?>assets/imgs/favicon.ico" media="screen" />
  <link href="<?=$siteurl?>assets/bootstrap3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
     <link href="<?=$siteurl?>assets/css/nifty.min.css" rel="stylesheet"/>
   <link href="<?=$siteurl?>assets/font-awesome4.7.0/css/font-awesome.min.css" rel="stylesheet"/>
  <script src="<?=$siteurl?>assets/jquery/jquery.min.js"></script>
  <script src="<?=$siteurl?>assets/bootstrap3.3.7/js/bootstrap.min.js"></script>
  <script src="<?=$siteurl?>assets/jquery/jquery.cookie.js"></script>
  <!--[if lt IE 9]>
    <script src="//cdn.bootcss.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
  <![endif]-->
  <script src="<?=$siteurl?>assets/layer/layer.js"></script>
  <script type="text/javascript">
     
  </script>
<style>
img.logo{
    width:14px;height:14px;margin:0 5px 0 3px;
}
body{
	background-image: url("assets/imgs/400x400a0a0.jpg");
	background-repeat:repeat;
        background-position: left;
}
</style>
</head>
<body>



<div style="height: 20px;">

</div>
<div class="container" >
<div class="col-xs-12 col-sm-10 col-md-8 col-lg-9 center-block" style="float: none;">
<div class="panel panel-default" style="border: 2px solid #63B8FF;">
    <div class="panel-body" style="text-align: center;" >
<img alt="" height="82px" src="assets/imgs/logo.png">

</div>
</div>

<div class="panel panel-primary">
<div class="panel-body" style="text-align: center;">
<div class="panel panel-info">

						<table class="table table-bordered">
							<tbody>
                                                            <tr>
                                                                <td colspan="2"  style="background: linear-gradient(to right,#8ae68a,#5ccdde,#8ae68a);color:black">
                                                                    店铺信息
                                                                </td>
                                                           
                                                            </tr>
								<tr>
                                                                    <td align="left" style="width: 50%;">
                                                                        <font color="#808080">店铺名称：</font><?=$conf['title']?> 
                                                                    </td>
                                                                    <td align="left" style="width: 50%;" rowspan="5" >
                                                                        <font color="#808080"><img src="<?=$siteurl?>assets/imgs/dpgg.png" height="16px;">&nbsp;店铺公告：</font>
                                                                        <br>  <?php echo $conf['notice1'];?>
                                                                         </td>
								</tr>
                                                                
                                                             <tr>
                                                                    <td align="left" style="width: 50%;"><font color="#808080">客服QQ：</font>
                                                                    <?php echo $conf['zzqq']; ?>
                                                                    </td>
								</tr>
                                                          <tr>
                                                              <td align="left" style="width: 50%;"><font color="#808080">店铺信誉：<img src="<?=$siteurl?>assets/imgs/hg.gif"></font></td>
								
								</tr>
                                                          <tr>
                                                                    <td align="left" style="width: 50%;"><font color="#808080">本站域名：<?=$siteurl?></font></td>
									
								</tr>
                                                                 <tr>
                                                                    <td align="left" style="width: 50%;">
                                                                        <a class="btn btn-primary" href="<?=$siteurl?>query.php" style=";margin-top: 3px;"><i class="fa fa-search fa-lg"></i> 查询订单</a>
                                                                        
                                                                        <a class="btn btn-primary" target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['zzqq']; ?>&site=qq&menu=yes" style="margin-top: 3px;"><i class="fa fa-qq fa-lg"></i> 联系客服</a>
                                                                        <button class="btn btn-primary" onclick="addme()" style="margin-top: 3px;"><i class="fa fa-star fa-lg"></i> 收藏本站</button>
                                                                    </td>
									
								</tr>
                                                         
								
							</tbody>
						</table>
						
						

</div>
    
    <!-- 店铺介绍结束 -->
    
    <!-- 商品展示 -->
    <div class="list-group" >
	<table class="table table-bordered">
							<tbody>
                                                            <tr>
                                                                <td colspan="2"  style="background: linear-gradient(to right,#9C9C9C,#5ccdde,#9C9C9C);color:black">
                                                                    在线购买
                                                                </td>
                                                           
                                                            </tr>
								<tr>
                                                                    <td align="left" style="width: 50%;">
                                                                        <select class="form-control" id="goodstype" onchange="getgoodslist(this.value)">
                                                                      
                                                                            <option value="<?=$type['id']?>" selected><?=$type['tName']?></option>
                                                                      
                                                                         </select>
                                                                       
                                                                    
                                                                    </td>
                                                                    <td align="left" style="width: 50%;; }" rowspan="5" >
                                                                        <font color="#808080"><img src="<?=$siteurl?>assets/imgs/dpgg.png" height="16px;">&nbsp;商品介绍：</font><br>
                                                                        <span id="goodsinfo" style="word-break:break-all;word-wrap:break-word;">
                                                                            <?=$goods['gInfo']?>
                                                                        </span>
                                                                         </td>
								</tr>
                                                                
                                                             <tr>
                                                                    <td align="left" style="width: 50%;">
                                                                        <select class="form-control" id="goodsshow" onchange="getgoodsmsg()">
                                                                            <option value="<?=$goods['id']?>" selected><?=$goods['gName']?></option>
                                                                        </select>
                                                                    </td>
								</tr>
                                                          <tr>
    <td align="left" >
      <div class="input-group">
		<span class="input-group-addon">商品价格：</span>
		<span  class="form-control" ><span id="goodsprice" style="color:red;font-size:14px;"><?=$goods['price']?></span>￥</span>
	</div>
        <div class="input-group">
		<span class="input-group-addon">商品库存：</span>
		<span  class="form-control" ><span id="goodskc"  style="color:red;font-size:14px;"><?=$kccount?></span>个</span>
	</div>
         
   
        

    </td>
								
								</tr>
<tr>
<td align="left" style="width: 50%;" id="number_xz">
    &nbsp;&nbsp;&nbsp;<font color="#808080">购买数量：</font>
    <div class="input-group-addon btn btn-primary" style="display:inline;width:30px;height:25px;" onclick='numstepUp()'>+</div>
<input type="number" onBlur="checknum()"  name="number" id="number"  min="1" step="1" value="1" required style="display:inline;width:30px;height:25px;">
<div class="input-group-addon btn btn-primary" style="display:inline;width:30px;height:25px;" onclick='numstepDown()'>-</div>

</td>
</tr>

<tr>                                                       
    <td align="left" style="width: 50%;">
        <div class="input-group">
		<span class="input-group-addon">联系QQ：</span>
		<input type="text" class="form-control" id="qq">
	</div>
    
    </td>
</tr>
<tr>
    <td  colspan="2" id="pay_type">
<?php
if($conf['switch_alipay']==1){
    echo ' <span class="btn btn-default btnSpan" title="alipay"><input type="radio" name="type" value="alipay" class="pay" id="alipay" value="alipay" title="支付宝" ><img alt="" src="'.$siteurl.'assets/alipay.ico" width="20" class="logo">支付宝</span>';
}
if($conf['switch_wxpay']==1){
    echo ' <span class="btn btn-default btnSpan"  title="wxpay"><input type="radio" name="type" value="wxpay" class="pay" id="wxpay" value="wxpay" title="微信" ><img alt="" src="'.$siteurl.'assets/wechat.ico" class="logo">微信</span>';
}
if($conf['switch_qqpay']==1){
    echo ' <span class="btn btn-default btnSpan" title="qqpay"><input type="radio" name="type" value="qqpay"  class="pay" id="qqpay" value="qqpay" title="QQ钱包" ><img alt="" src="'.$siteurl.'assets/qqpay.ico" class="logo">QQ</span>';
}
if($conf['switch_tenpay']==1){
    echo ' <span class="btn btn-default btnSpan" title="tenpay"><input type="radio" name="type" value="tenpay" class="pay" id="tenpay" value="tenpay" title="财付通" ><img alt="" src="'.$siteurl.'assets/tenpay.ico" class="logo"> 财付通</span>';
}
?>
   
 
  

           
   </td>
  
<tr>
    <td align="left" colspan="2" style="width: 50%;">
        <input type="button"  style="height: 40px;line-height: 20px;" class="form-control btn btn-primary" value="立即购买" onclick="submit_orders()" id="submit_btn">
   </td>
                                                                  
								</tr>
								
							</tbody>
						</table>
			
			
	</div>
	
		
		<hr/>
		<div class="container-fluid">
		<a  target="_blank"   href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['zzqq']; ?>&site=qq&menu=yes" class="btn btn-info btn-sm"><span class="glyphicon glyphicon-user"></span> 联系客服</a>
		</div>
		<br>
		<span><?= $conf['foot'] ?></span>
		
		
		
		</div>
	</div>
</div>
</div>
  <script src="<?=$siteurl?>assets/js/index.js"></script>
</body>
</html>
<script>
    kcnumber = <?=$kccount?>;
function addme(){
    url = document.URL;
    title = $("#bttt").text(); 
    window.external.AddFavorite(url, title);
}
</script>