<?php
@header('Content-Type: text/html; charset=UTF-8');

/*
echo '<pre>';
var_dump($json);
echo '</pre>';
exit();*/
?>

<!DOCTYPE html>
<html lang="zh-cn">
<head>
  <meta charset="utf-8"/>
   <meta content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no"  name="viewport" />
  <title id="bttt">订单提取 - <?=$conf['title']?> - <?php echo  $conf['ftitle'];  ?></title>
  <meta name="keywords" content="<?php echo $conf['keywords']; ?>">
  <meta name="description" content="<?php echo $conf['description'];  ?>">
   <link rel="shortcut icon" type="image/x-icon" href="<?=$siteurl?>assets/imgs/favicon.ico" media="screen" />
  <link href="<?=$siteurl?>assets/bootstrap3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
     <link href="<?=$siteurl?>assets/css/nifty.min.css" rel="stylesheet"/>
   <link href="<?=$siteurl?>assets/font-awesome4.7.0/css/font-awesome.min.css" rel="stylesheet"/>
  <script src="<?=$siteurl?>assets/jquery/jquery.min.js"></script>
  <script src="<?=$siteurl?>assets/bootstrap3.3.7/js/bootstrap.min.js"></script>
  <script src="<?=$siteurl?>assets/jquery/jquery.cookie.js"></script>
  <!--[if lt IE 9]>
    <script src="//cdn.bootcss.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
  <![endif]-->
  <script src="<?=$siteurl?>assets/layer/layer.js"></script>
  <script type="text/javascript">
     
      
  $(function(){
    })
 
  </script>
<style>
img.logo{
    width:14px;height:14px;margin:0 5px 0 3px;
}
body{
	background-image: url("assets/imgs/400x400a0a0.jpg");
	background-repeat:repeat;
        background-position: left;
}
</style>
</head>
<body>



<div style="height: 20px;">

</div>
<div class="container" >
<div class="col-xs-12 col-sm-10 col-md-8 col-lg-9 center-block" style="float: none;">
<div class="panel panel-default" style="border: 2px solid #63B8FF;">
    <div class="panel-body" style="text-align: center;" >
<img alt="" height="82px" src="assets/imgs/logo.png">

</div>
</div>

<div class="panel panel-primary">
<div class="panel-body" style="text-align: center;">
<div class="panel panel-info">

						<table class="table table-bordered">
							<tbody>
                                                            <tr>
                                                                <td colspan="2"  style="background: linear-gradient(to right,#8ae68a,#5ccdde,#8ae68a);color:black">
                                                                    店铺信息
                                                                </td>
                                                           
                                                            </tr>
								<tr>
                                                                    <td align="left" style="width: 50%;">
                                                                        <font color="#808080">店铺名称：</font><?=$conf['title']?> 
                                                                    </td>
                                                                    <td align="left" style="width: 50%;" rowspan="5" >
                                                                        <font color="#808080"><img src="<?=$siteurl?>assets/imgs/dpgg.png" height="16px;">&nbsp;发货公告：</font>
                                                                        <br>  <?php echo $conf['dd_notice'];?>
                                                                         </td>
								</tr>
                                                                
                                                             <tr>
                                                                    <td align="left" style="width: 50%;"><font color="#808080">客服QQ：</font>
                                                                        <a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['zzqq']; ?>&site=qq&menu=yes" target="_blank"><?php echo $conf['zzqq']; ?></a>
                                                                    </td>
								</tr>
                                                          <tr>
                                                              <td align="left" style="width: 50%;"><font color="#808080">店铺信誉：<img src="<?=$siteurl?>assets/imgs/hg.gif"></font></td>
								
								</tr>
                                                          <tr>
                                                                    <td align="left" style="width: 50%;"><font color="#808080">本站域名：<?=$siteurl?></font></td>
									
								</tr>
                                                                  <tr>
                                                                    <td align="left" style="width: 50%;">
                                                                        <a class="btn btn-primary" href="<?=$siteurl?>index.php" style=";margin-top: 3px;"><i class="fa fa-home fa-lg"></i>
                                                                            网站首页</a>
                                                                        
                                                                        <a class="btn btn-primary" target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['zzqq']; ?>&site=qq&menu=yes" style="margin-top: 3px;"><i class="fa fa-qq fa-lg"></i> 联系客服</a>
                                                                        <button class="btn btn-primary" onclick="addme()" style="margin-top: 3px;"><i class="fa fa-star fa-lg"></i> 收藏本站</button>
                                                                    </td>
									
								</tr>
                                                         
								
							</tbody>
						</table>
						
						

</div>
    
    <!-- 店铺介绍结束-->
    
    <!-- 查询 -->
    <div class="list-group" >
        <form action="" method="POST">
         <div  class="form-group" style="background: linear-gradient(to right,#9C9C9C,#5ccdde,#9C9C9C);color:black;height: 30px;line-height: 30px;">
                                                                   订单查询
          </div>
        <div class="input-group" style="height:30px;">
		<span class="input-group-addon">联系QQ/订单编号：</span>
                <input type="text" class="form-control" name="no" id="no" value="<?=@$_REQUEST['no']?>">
	</div>
        <br>
        <?php
        if(!empty($_REQUEST['no'])){
            $no = daddslashes($_REQUEST['no']);
            $no = _ayangw($no);
            $sql = "select * from ayangw_km where out_trade_no = '$no' or trade_no = '$no' or rel = '$no'  order by id desc";
            $rs = $DB->query($sql);
            
            ?>
      
        <div>
            <div style="text-align:left;display: block;">
                <span style=";font-size: 14px;font-weight: bold;color:black">搜索凭证：<?=$no?></span>
            </div>
            <table  class="table">
                <tr>
                    <th>商品名称</th>
                    <th>卡密</th>
                    <th>时间</th>
                </tr>
                
                <?php
                while ($row = $DB->fetch($rs)){
                    $grow = getgoods($row['gid']);
                    ?>
                    <tr>
                        <th><?=$grow['gName']?></th>
                        <th><?=$row['km']?></th>
                        <th><?=$row['endTime']?></th>
                    </tr>    
                    <?php
                }
                ?>
                
            </table>
            
        </div>
        <?php
 
         }?>
        
          <div class="form-group">
              <button class="form-control btn btn-primary" >立即查询</button>
	</div>
        </form>
    </div>
	
		
		<hr/>
		<div class="container-fluid">
		<a  target="_blank"  href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['zzqq']; ?>&site=qq&menu=yes" class="btn btn-info btn-sm"><span class="glyphicon glyphicon-user"></span> 联系客服</a>
		</div>
		<br>
		<span><?= $conf['foot'] ?></span>
		
		
		
		</div>
	</div>
</div>
</div>

</body>
</html>
<script>
function addme(){
    url = document.URL;
    title = $("#bttt").text(); 
    window.external.AddFavorite(url, title);
}
$(function(){
    var tradeno = $.cookie('tradeno');
    if($("#no").val() == ""){
        $("#no").val(tradeno);
    }
})
</script>