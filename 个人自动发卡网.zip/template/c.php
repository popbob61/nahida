﻿<?php

$data = array(
    "temp_name" => "仿商城模板",
    "temp_summary" => "列表展示商品",
     "temp_description" => "1.本模板为自适应模板·2.不适合商品太多的网址",
    "temp_dir" => "listshow",
    "temp_author" => "人心",
    "temp_buiid" =>"6.0.0",
    "temp_time" =>"2018-7-21",
    "temp_demo_url" => "http://blog.11awz.cn",
    "temp_gw" => "http://blog.11awz.cn"
);
echo '<pre>';
exit(json_encode($data)."</pre>");