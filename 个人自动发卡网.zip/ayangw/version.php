<?php
return array(
    'version'=>'6.5.0',
    'build' => '1065',
    'sqlversion' =>'1065'
);
