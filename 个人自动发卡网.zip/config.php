<?php
/*数据库配置*/
$dbconfig=array(
	'host' => 'localhost', //数据库服务器
	'port' => 3306, //数据库端口
	'user' => 'ser260471162084', //数据库用户名
	'pwd' => 'bgTfys5N9pII', //数据库密码
	'dbname' => 'ser260471162084' //数据库名
);
?>