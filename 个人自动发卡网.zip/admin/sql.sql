-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2022-09-25 12:56:15
-- 服务器版本： 5.6.50-log
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ser260471162084`
--

-- --------------------------------------------------------

--
-- 表的结构 `ayangw_blacklist`
--

CREATE TABLE IF NOT EXISTS `ayangw_blacklist` (
  `id` int(11) NOT NULL,
  `type` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `data` varchar(200) DEFAULT NULL,
  `remarks` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `ayangw_config`
--

CREATE TABLE IF NOT EXISTS `ayangw_config` (
  `ayangw_k` varchar(255) NOT NULL DEFAULT '',
  `ayangw_v` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `ayangw_config`
--

INSERT INTO `ayangw_config` (`ayangw_k`, `ayangw_v`) VALUES
('title', '个人发卡网'),
('keywords', '个人发卡网,自动发卡网'),
('description', '123456'),
('zzqq', '123456'),
('notice2', '付款后按提示点击确定跳转到提取页面，不可提前关闭窗口！否则无法提取到卡密！'),
('notice3', '提取码是订单编号 或者 您的联系方式！'),
('notice1', '提取卡密后请尽快激活使用或保存好，系统定期清除被提取的卡密'),
('foot', '个人发卡网'),
('dd_notice', '1.联系方式也可以作为你的提卡凭证<br>2.必须等待付款完成自动跳转，不可提前关闭页面，否则会导致订单失效，后果自负'),
('admin', 'admin'),
('pwd', 'f3b4e3b975e0484835e90514f8318e61'),
('web_url', ''),
('payapi', '9'),
('epay_id', '140271754'),
('epay_key', 'LMOv9eifsGE'),
('showKc', '1'),
('CC_Defender', '2'),
('txprotect', '0'),
('qqtz', '1'),
('sqlv', '1060'),
('cygg', ''),
('syslog', '1'),
('showImgs', '1'),
('submit', '保存修改'),
('switch_alipay', '1'),
('switch_wxpay', '1'),
('switch_qqpay', '1'),
('switch_tenpay', '0'),
('view', 'default'),
('epay_url', 'http://pay.x70.cc/'),
('ftitle', '   ');

-- --------------------------------------------------------

--
-- 表的结构 `ayangw_goods`
--

CREATE TABLE IF NOT EXISTS `ayangw_goods` (
  `id` int(11) NOT NULL,
  `gName` varchar(255) DEFAULT NULL,
  `gInfo` text,
  `imgs` varchar(110) DEFAULT NULL,
  `tpId` int(11) NOT NULL COMMENT 'Ã¦â€°â‚¬Ã¥Â±Å¾Ã¥Ë†â€ Ã§Â±Â»',
  `price` float DEFAULT NULL,
  `state` int(11) DEFAULT '1',
  `sotr` int(4) DEFAULT '1',
  `sales` int(11) DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `ayangw_goods`
--

INSERT INTO `ayangw_goods` (`id`, `gName`, `gInfo`, `imgs`, `tpId`, `price`, `state`, `sotr`, `sales`) VALUES
(1, '易夏云', '易夏云', 'assets/goodsimg/1664081561.png', 1, 0.01, 1, 1, 0);

-- --------------------------------------------------------

--
-- 表的结构 `ayangw_km`
--

CREATE TABLE IF NOT EXISTS `ayangw_km` (
  `id` int(11) NOT NULL,
  `gid` int(11) NOT NULL,
  `km` varchar(100) DEFAULT NULL,
  `benTime` datetime DEFAULT NULL,
  `endTime` datetime DEFAULT NULL,
  `out_trade_no` varchar(100) DEFAULT NULL,
  `trade_no` varchar(100) DEFAULT NULL,
  `rel` varchar(50) DEFAULT NULL,
  `stat` int(11) DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `ayangw_km`
--

INSERT INTO `ayangw_km` (`id`, `gid`, `km`, `benTime`, `endTime`, `out_trade_no`, `trade_no`, `rel`, `stat`) VALUES
(1, 1, '测试 \r', '2022-09-25 12:55:09', NULL, NULL, NULL, NULL, 0),
(2, 1, '测试\r', '2022-09-25 12:55:09', NULL, NULL, NULL, NULL, 0),
(3, 1, '测试\r', '2022-09-25 12:55:09', NULL, NULL, NULL, NULL, 0),
(4, 1, '测试', '2022-09-25 12:55:09', NULL, NULL, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- 表的结构 `ayangw_order`
--

CREATE TABLE IF NOT EXISTS `ayangw_order` (
  `id` int(11) NOT NULL,
  `out_trade_no` varchar(100) DEFAULT NULL,
  `trade_no` varchar(100) DEFAULT NULL,
  `md5_trade_no` varchar(100) DEFAULT NULL,
  `gid` int(11) DEFAULT NULL,
  `money` float DEFAULT NULL,
  `rel` varchar(30) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `benTime` datetime DEFAULT NULL,
  `endTime` datetime DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `sta` int(11) DEFAULT '0',
  `sendE` int(11) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `ayangw_syslog`
--

CREATE TABLE IF NOT EXISTS `ayangw_syslog` (
  `id` int(11) NOT NULL,
  `log_name` varchar(20) DEFAULT NULL,
  `log_time` datetime DEFAULT NULL,
  `log_txt` text
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `ayangw_syslog`
--

INSERT INTO `ayangw_syslog` (`id`, `log_name`, `log_time`, `log_txt`) VALUES
(1, '登陆后台成功!', '2022-09-25 12:45:39', '登陆IP:59.57.203.169'),
(2, '修改系统配置', '2022-09-25 12:51:15', 'IP:59.57.203.169,修改了系统配置');

-- --------------------------------------------------------

--
-- 表的结构 `ayangw_type`
--

CREATE TABLE IF NOT EXISTS `ayangw_type` (
  `id` int(11) NOT NULL,
  `tName` varchar(100) DEFAULT NULL,
  `sort` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `ayangw_type`
--

INSERT INTO `ayangw_type` (`id`, `tName`, `sort`, `state`) VALUES
(1, '易夏云', 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ayangw_blacklist`
--
ALTER TABLE `ayangw_blacklist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ayangw_config`
--
ALTER TABLE `ayangw_config`
  ADD PRIMARY KEY (`ayangw_k`);

--
-- Indexes for table `ayangw_goods`
--
ALTER TABLE `ayangw_goods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ayangw_km`
--
ALTER TABLE `ayangw_km`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ayangw_order`
--
ALTER TABLE `ayangw_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ayangw_syslog`
--
ALTER TABLE `ayangw_syslog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ayangw_type`
--
ALTER TABLE `ayangw_type`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ayangw_blacklist`
--
ALTER TABLE `ayangw_blacklist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ayangw_goods`
--
ALTER TABLE `ayangw_goods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `ayangw_km`
--
ALTER TABLE `ayangw_km`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `ayangw_order`
--
ALTER TABLE `ayangw_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ayangw_syslog`
--
ALTER TABLE `ayangw_syslog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `ayangw_type`
--
ALTER TABLE `ayangw_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
